Para visualização do modelo por inteiro, abrir o ficheiro "PROTOTIPO2.SLDASM" .
